package abraham_leila_kviz;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Abraham_Leila_Kviz {

    public static void main(String[] args) {
        
    int ujKezdes = 1;
    while(ujKezdes == 1){

            String nev = JOptionPane.showInputDialog("Adja meg a nevét! Min. 3 karakter: ");
            String cim = "Programozási kvíz";
            boolean jo = nev.length()>=3;
            String kerdes;
            int pont = 0;
            int maxpont = 5;
            int msgType;
            msgType = JOptionPane.INFORMATION_MESSAGE;
            int info = JOptionPane.OK_OPTION;

            while(!jo){
                nev = JOptionPane.showInputDialog("Adja meg a nevét! Minimum 3 karakter: ");
                if(nev.length()>=3){
                    jo = true;
                }
             }

            int nevhossz = nev.length();

             for (int i = 0; i < nevhossz; i++) {
                 boolean vanBenneSzam = nev.charAt(i) == '0' || nev.charAt(i) == '1' || nev.charAt(i) == '2' ||
                         nev.charAt(i) == '3' || nev.charAt(i) == '4' || nev.charAt(i) == '5' ||
                         nev.charAt(i) == '6' || nev.charAt(i) == '7' || nev.charAt(i) == '8' ||
                         nev.charAt(i) == '9';
                 while(vanBenneSzam){
                     nev = JOptionPane.showInputDialog("Adja meg a nevét! Nincs szám: ");
                         vanBenneSzam = nev.charAt(i) == '0' || nev.charAt(i) == '1' || nev.charAt(i) == '2' ||
                         nev.charAt(i) == '3' || nev.charAt(i) == '4' || nev.charAt(i) == '5' ||
                         nev.charAt(i) == '6' || nev.charAt(i) == '7' || nev.charAt(i) == '8' ||
                         nev.charAt(i) == '9';
                 }

             }


             msgType = JOptionPane.INFORMATION_MESSAGE;
             JOptionPane.showMessageDialog(null, nev, cim, msgType);

             msgType = JOptionPane.QUESTION_MESSAGE;
             kerdes = "Melyik a legnagyobb egészszám változó? ";

             Object[] valtozok = {"short", "int", "byte", "long"};
             Icon kep = new ImageIcon("src//kepek//kep.png");
             Object kijelolve = "...";
             Object valasztas = JOptionPane.showInputDialog(null, kerdes, cim, msgType, kep, valtozok, kijelolve);
             if(valasztas == "long"){
                 pont++;
             }

             kerdes = "A java OOP nyelv.";
             info = JOptionPane.YES_NO_OPTION;
             int gomb = JOptionPane.showConfirmDialog(null, kerdes, cim, info, msgType);
             if(gomb == JOptionPane.YES_OPTION){
                 pont++;
             }

             kerdes = "Melyik nem ciklus?";
             Object[] ciklusok = {"for","for each","if","while","do while"};
             kep = new ImageIcon("src//kepek//kep.png");
             kijelolve = "...";
             Object valasztas2 = JOptionPane.showInputDialog(null, kerdes, cim, msgType, kep, ciklusok, kijelolve);
             if(valasztas2 == "if"){
                 pont++;
             }


             kerdes = "Melyik nem prgramozási tétel?";
             Object[] tetelek = {"Megszámlálás tétele","Maximum kiválasztás tétele","Kiválasztás tétele","Beszúrás tétele","Eldöntés tétele"};
             Object valasztas3 = JOptionPane.showInputDialog(null, kerdes, cim, msgType, kep, tetelek, kijelolve);
             if(valasztas3 == "Beszúrás tétele"){
                 pont++;
             }


             kerdes = "Mi lesz az eredménye a Math.sqrt(36)-nak?";
             String valasztas4 = JOptionPane.showInputDialog(null, kerdes, cim, msgType);
             int szamvalasz = Integer.parseInt(valasztas4);
             if(szamvalasz == 6){
                 pont++;
             }


             kerdes = "Melyik logikai változó?";
             Object[] logikai = {"doube","short","boolean","float"};
             Object valasztas5 = JOptionPane.showInputDialog(null, kerdes, cim, msgType, kep, logikai, kijelolve);
             if(valasztas5 == "boolean"){
                 pont++;
             }

             String uzenet = "Gratulálok! Az eredményed: " + pont+"\n Szeretnéd újra kezdeni?";
             info = JOptionPane.YES_NO_OPTION;
             gomb = JOptionPane.showConfirmDialog(null, uzenet, cim, info, msgType);
             if(gomb == JOptionPane.YES_OPTION){
                   ujKezdes = 1;
             }
             else{
                 System.exit(0);
             }
        }
    }
}
